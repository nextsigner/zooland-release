#!/bin/bash
cat $1 | grep $2
